export interface Category {
    id: number;
    name: string;
    // Add additional properties as needed
  }
  