import { Component } from '@angular/core';
import { Category } from 'src/app/category.model';
import { CategoryFacade } from 'src/app/store/category.facade';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent {
  categories:any[] | undefined //Category[] | undefined;

  constructor(private categoryFacade: CategoryFacade) {}

  ngOnInit() {
    debugger;
    this.categoryFacade.loadCategories();
    this.categoryFacade.categories$.subscribe((categories: any[] | undefined) => {
      this.categories = categories;
    });
  }
}
