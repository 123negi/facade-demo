import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { loadCategoryData } from '../store/app.action';
import { selectCategoryData, selectCategoryError, selectCategoryLoading } from '../store/app.selector';

@Injectable({
  providedIn: 'root'
})
export class AppFacadeService {


  data$: Observable<any[]>;
  loading$: Observable<boolean>;
  error$: Observable<any>;

  constructor(private store: Store<any>) {
    this.data$ = this.store.select(selectCategoryData);
    this.loading$ = this.store.select(selectCategoryLoading);
    this.error$ = this.store.select(selectCategoryError);
  }

  loadData() {
    this.store.dispatch(loadCategoryData());
  }
}
