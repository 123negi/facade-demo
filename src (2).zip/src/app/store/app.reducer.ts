import { state } from '@angular/animations';
import { createReducer, on } from '@ngrx/store';
import {
  loadCategoryData,
  loadCategoryDataFailure,
  loadCategoryDataSuccess,
} from './app.action';
import { initialState } from './app.state';

export const _appReducer = createReducer(
  initialState,
  on(loadCategoryData, (state) => ({ ...state, loading: true })),
  on(loadCategoryDataSuccess, (state, res) => ({
    ...state,
    res,
    loading: false,
  })),
  on(loadCategoryDataFailure, (state, { error }) => ({
    ...state,
    error,
    loading: false,
  }))
);
export function appReducer(state: any, action: any) {
  return _appReducer(state, action);
}
