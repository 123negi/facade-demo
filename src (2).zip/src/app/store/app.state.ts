export const initialState = {
    data: [],
    loading: false,
    error: null
  }