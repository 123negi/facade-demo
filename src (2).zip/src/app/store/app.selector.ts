import { createFeatureSelector, createSelector } from '@ngrx/store';

const selectorCategoryState = createFeatureSelector<any>('data');

export const selectCategoryData = createSelector(
  selectorCategoryState,
  (categoryData) => categoryData.data
);

export const selectCategoryLoading = createSelector(
  selectorCategoryState,
  (categoryData) => categoryData.loading
);

export const selectCategoryError = createSelector(
  selectorCategoryState,
  (categoryData) => categoryData.error
);
