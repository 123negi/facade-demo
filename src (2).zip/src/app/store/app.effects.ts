import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, switchMap, tap } from 'rxjs/operators';

import * as CategoryActions from './app.action';
import { CategoryService } from '../shared/category.service';

@Injectable()
export class CategoryEffects {
  loadCategories$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CategoryActions.loadCategoryData),
      switchMap(() =>
        this.categoryService.getAllCategories().pipe(
          map(data => CategoryActions.loadCategoryDataSuccess({ data })),
          catchError(error =>
            of(CategoryActions.loadCategoryDataFailure({ error: error.message }))
          )
        )
      )
    )
  );

  constructor(
    private actions$: Actions,
    private categoryService: CategoryService
  ) {}
}
