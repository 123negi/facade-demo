import { createAction, props } from '@ngrx/store';

export const loadCategoryData = createAction(
  '[CategoryData] Load Category Data'
);
export const loadCategoryDataSuccess = createAction(
  '[CategoryData] Load Category Data Success',
  props<{ data: any[] }>()
);
export const loadCategoryDataFailure = createAction(
  '[CategoryData] Load Category Data Failure',
  props<{ error: any }>()
);


