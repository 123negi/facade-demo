import { Component, OnInit } from '@angular/core';
import { AppFacadeService } from '../shared/app-facade.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  data$ = this.facadeService.data$;
  loading$ = this.facadeService.loading$;
  error$ = this.facadeService.error$;

  constructor(private facadeService:AppFacadeService ) {}

  ngOnInit() {
    this.facadeService.loadData();
     this.data$.subscribe(data=> console.log(data,"data"))
  }

}
